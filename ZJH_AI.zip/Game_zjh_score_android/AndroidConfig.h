﻿#pragma once

//#include <types.h>
#include "ITableFrameSink.h"
#include "../QPAlgorithm/zjh.h"
#include "Globals.h"
#include "IAndroidUserItemSink.h"
#include "IServerUserItem.h"
#include "proto/zjh.Message.pb.h"
#include <functional>
#include <utility>
#include <math.h>
#include <vector>

struct param_t {
	//看牌参数
	float K_;
	//牌比玩家大，权值倍率，修正参数
	float W1_, P1_;
	//牌比玩家小，权值倍率，修正参数
	float W2_, P2_;
};

//机器人牌型对应胜率/权值
struct robotconfig_t {
	//放大倍数
	int scale;
	//收分[0]/正常[1]/放分[2]，看牌参数，权值倍率，修正参数
	param_t param[3];
	//看牌概率
	int ratioKP[3];
	//豹子
	std::pair<double, double> _30;
	//同花顺
	std::pair<double, double> _123sc;
	//同花
	std::pair<double, double> _Asc;
	std::pair<double, double> _Ksc;
	std::pair<double, double> _Qsc;
	std::pair<double, double> _Jsc;
	std::pair<double, double> _Tsc;
	std::pair<double, double> _9sc;
	std::pair<double, double> _8sc;
	std::pair<double, double> _7sc;
	std::pair<double, double> _6sc;
	std::pair<double, double> _5sc;
	//顺子
	std::pair<double, double> _QKA;
	std::pair<double, double> _JQK;
	std::pair<double, double> _TJQ;
	std::pair<double, double> _9TJ;
	std::pair<double, double> _89T;
	std::pair<double, double> _789;
	std::pair<double, double> _678;
	std::pair<double, double> _567;
	std::pair<double, double> _456;
	std::pair<double, double> _345;
	std::pair<double, double> _234;
	std::pair<double, double> _A23;
	//对子
	std::pair<double, double> _AA;
	std::pair<double, double> _KK;
	std::pair<double, double> _QQ;
	std::pair<double, double> _JJ;
	std::pair<double, double> _TT;
	std::pair<double, double> _99;
	std::pair<double, double> _88;
	std::pair<double, double> _77;
	std::pair<double, double> _66;
	std::pair<double, double> _55;
	std::pair<double, double> _44;
	std::pair<double, double> _33;
	std::pair<double, double> _22;
	//散牌
	std::pair<double, double> _A;
	std::pair<double, double> _K;
	std::pair<double, double> _Q;
	std::pair<double, double> _J;
	std::pair<double, double> _10;
	std::pair<double, double> _9;
	std::pair<double, double> _8;
	std::pair<double, double> _7;
	std::pair<double, double> _6;
	std::pair<double, double> _5;
};