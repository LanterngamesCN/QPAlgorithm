﻿#ifndef CMD_QZqzzjh::HEAD_FILE
#define CMD_QZqzzjh::HEAD_FILE

#include <math.h>
#include <stdio.h>
#include <string.h>
#include "gameDefine.h"

//数值定义
#define MAX_JETTON_MUL							4								//下注倍数个数
#define MAX_BANKER_MUL							3								//叫庄倍数个数
#define MAX_BANKER_CALL							4+1								//叫庄最大倍数

#endif
