﻿
#include <iostream>
#include <stdlib.h>
#include "../QPAlgorithm/zjh.h"

#ifdef WIN32
#include <windows.h>
#define xsleep(t) Sleep(t*1000)
#define clscr() system("cls")
#else
#include <unistd.h>
#define xsleep(t) sleep(t)
#define clscr() system("reset")
#endif

#include <sstream>
#include <vector>
#include <boost/algorithm/algorithm.hpp>
#include <boost/algorithm/string.hpp>
#include "../public/weights.h"
int main()
{
	//ZJH::CGameLogic::TestCards("./conf/qzzjh_cardList.ini");

	//std::stringstream iStr;
	//for (int i = 0; i < 5; ++i) {
	//	iStr << "s";
	//}
// 	printf("%s\n", iStr.str().c_str());
// 	std::string ip = "192.168.2.12:8088";
// 	std::vector<std::string> vec;
// 	boost::algorithm::split(vec, ip, boost::is_any_of(":"));
// 	printf("vec.size = %d v[0]=%s v[1]=%s v[2]=%s\n", vec.size(), vec[0].c_str(), vec[1].c_str(), vec[2].c_str());
// 	if (int size = 5) {
// 		printf("%d", size);
// 	}
	
	TestWeightsRatio("/home/testratio.txt");
	return 0;
}
