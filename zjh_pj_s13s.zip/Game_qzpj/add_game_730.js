// usecase:
//mongo -u txkj007 -p aa123465 --authenticationDatabase admin  192.168.2.226:37017/gamemain e:/mongoscript/agentid_fix.js > e:/mongoscript/update.log
//mongo 192.168.2.97:27017/gameconfig e:/mongoscript/add_game_730.js
var s = db.getMongo().startSession()
var android_strategy = "android_strategy";
var game_kind = "game_kind";

var android_strategy_data_7301 = {
    "gameid" : NumberInt(730),
    "roomid" : NumberInt(7301),
    "exitLowScore" : NumberLong(2000),
    "exitHighScore" : NumberLong(40000),
    "minScore" : NumberLong(4000),
    "maxScore" : NumberLong(20000),
    "areas" : [ 
        {
            "weight" : NumberInt(250),
            "lowTimes" : NumberInt(500),
            "highTimes" : NumberInt(1000)
        }, 
        {
            "weight" : NumberInt(500),
            "lowTimes" : NumberInt(1000),
            "highTimes" : NumberInt(2000)
        }, 
        {
            "weight" : NumberInt(7500),
            "lowTimes" : NumberInt(2000),
            "highTimes" : NumberInt(3500)
        }, 
        {
            "weight" : NumberInt(9500),
            "lowTimes" : NumberInt(3500),
            "highTimes" : NumberInt(4500)
        }, 
        {
            "weight" : NumberInt(1000),
            "lowTimes" : NumberInt(4500),
            "highTimes" : NumberInt(50000)
        }
    ]
}
var android_strategy_data_7302 = {
    "gameid" : NumberInt(730),
    "roomid" : NumberInt(7302),
    "exitLowScore" : NumberLong(20000),
    "exitHighScore" : NumberLong(400000),
    "minScore" : NumberLong(40000),
    "maxScore" : NumberLong(200000),
    "areas" : [ 
        {
            "weight" : NumberInt(250),
            "lowTimes" : NumberInt(500),
            "highTimes" : NumberInt(1000)
        }, 
        {
            "weight" : NumberInt(500),
            "lowTimes" : NumberInt(1000),
            "highTimes" : NumberInt(2000)
        }, 
        {
            "weight" : NumberInt(7500),
            "lowTimes" : NumberInt(2000),
            "highTimes" : NumberInt(3500)
        }, 
        {
            "weight" : NumberInt(9500),
            "lowTimes" : NumberInt(3500),
            "highTimes" : NumberInt(4500)
        }, 
        {
            "weight" : NumberInt(1000),
            "lowTimes" : NumberInt(4500),
            "highTimes" : NumberInt(50000)
        }
    ]
}
var android_strategy_data_7303 = {
    "gameid" : NumberInt(730),
    "roomid" : NumberInt(7303),
    "exitLowScore" : NumberLong(50000),
    "exitHighScore" : NumberLong(1000000),
    "minScore" : NumberLong(100000),
    "maxScore" : NumberLong(500000),
    "areas" : [ 
        {
            "weight" : NumberInt(250),
            "lowTimes" : NumberInt(500),
            "highTimes" : NumberInt(1000)
        }, 
        {
            "weight" : NumberInt(500),
            "lowTimes" : NumberInt(1000),
            "highTimes" : NumberInt(2000)
        }, 
        {
            "weight" : NumberInt(7500),
            "lowTimes" : NumberInt(2000),
            "highTimes" : NumberInt(3500)
        }, 
        {
            "weight" : NumberInt(9500),
            "lowTimes" : NumberInt(3500),
            "highTimes" : NumberInt(4500)
        }, 
        {
            "weight" : NumberInt(1000),
            "lowTimes" : NumberInt(4500),
            "highTimes" : NumberInt(50000)
        }
    ]
}
var android_strategy_data_7304 = {
    "gameid" : NumberInt(730),
    "roomid" : NumberInt(7304),
    "exitLowScore" : NumberLong(100000),
    "exitHighScore" : NumberLong(2000000),
    "minScore" : NumberLong(200000),
    "maxScore" : NumberLong(1000000),
    "areas" : [ 
        {
            "weight" : NumberInt(250),
            "lowTimes" : NumberInt(500),
            "highTimes" : NumberInt(1000)
        }, 
        {
            "weight" : NumberInt(500),
            "lowTimes" : NumberInt(1000),
            "highTimes" : NumberInt(2000)
        }, 
        {
            "weight" : NumberInt(7500),
            "lowTimes" : NumberInt(2000),
            "highTimes" : NumberInt(3500)
        }, 
        {
            "weight" : NumberInt(9500),
            "lowTimes" : NumberInt(3500),
            "highTimes" : NumberInt(4500)
        }, 
        {
            "weight" : NumberInt(1000),
            "lowTimes" : NumberInt(4500),
            "highTimes" : NumberInt(50000)
        }
    ]
}

var game_kind_data_730 = {
	'gameid' : NumberInt(730),
	'gamename' : '抢庄牌九',
	'sort' : NumberInt(0),
	'servicename' : 'Game_qzpj',
	'revenueRatio' : NumberInt(5),
	'type' : NumberInt(1),
	'ishot' : NumberInt(0),
	'status' : NumberInt(1),
	'updatePlayerNum' : NumberInt(30),
	'rooms' : [ 
		{
			'roomid' : NumberInt(7301),
			'roomname' : '体验房',
			'tablecount' : NumberInt(100),
			'floorscore' : NumberLong(100),
			'ceilscore' : NumberLong(-1),
			'minplayernum' : NumberInt(2),
			'maxplayernum' : NumberInt(4),
			'enterminscore' : NumberLong(2000),
			'entermaxscore' : NumberLong(-1),
			'broadcastscore' : NumberLong(500000),
			'enableandroid' : NumberInt(1),
			'androidcount' : NumberInt(3),
			'androidmaxusercount' : NumberInt(3),
			'totalstock' : NumberLong(500160000),
			'totalstocklowerlimit' : NumberLong(500000000),
			'totalstockhighlimit' : NumberLong(500320000),
			'systemkillallratio' : NumberInt(0),
			'systemreduceratio' : NumberInt(0),
			'changecardratio' : NumberInt(0),
			'maxjettonscore' : NumberLong(2500),
			'jettons' : {
				'_t' : 'System.Int64[]',
				'_v' : [ 
					NumberLong(1), 
					NumberLong(8), 
					NumberLong(15), 
					NumberLong(22),
					NumberLong(30)
				]
			},
			"androidPercentage" : {
                "_t" : "System.Double[]",
                "_v" : [ 
                    0.77, 
                    0.61, 
                    0.45, 
                    0.33, 
                    0.25, 
                    0.24, 
                    0.29, 
                    0.38, 
                    0.45, 
                    0.53, 
                    0.62, 
                    0.66, 
                    0.97, 
                    0.99, 
                    0.85, 
                    0.77, 
                    0.81, 
                    0.77, 
                    0.75, 
                    0.72, 
                    0.74, 
                    0.81, 
                    0.82, 
                    0.77
                ]
            },
			'status' : NumberInt(1),
			'realChangeAndroid' : NumberInt(0)
		}, 
		{
			'roomid' : NumberInt(7302),
			'roomname' : '初级房',
			'tablecount' : NumberInt(100),
			'floorscore' : NumberLong(500),
			'ceilscore' : NumberLong(-1),
			'minplayernum' : NumberInt(2),
			'maxplayernum' : NumberInt(4),
			'enterminscore' : NumberLong(20000),
			'entermaxscore' : NumberLong(-1),
			'broadcastscore' : NumberLong(500000),
			'enableandroid' : NumberInt(1),
			'androidcount' : NumberInt(3),
			'androidmaxusercount' : NumberInt(3),
			'totalstock' : NumberLong(500160000),
			'totalstocklowerlimit' : NumberLong(500000000),
			'totalstockhighlimit' : NumberLong(501600000),
			'systemkillallratio' : NumberInt(0),
			'systemreduceratio' : NumberInt(0),
			'changecardratio' : NumberInt(0),
			'maxjettonscore' : NumberLong(10000),
			'jettons' : {
				'_t' : 'System.Int64[]',
				'_v' : [ 
					NumberLong(1), 
					NumberLong(8), 
					NumberLong(15), 
					NumberLong(22),
					NumberLong(30)
				]
			},
			"androidPercentage" : {
                "_t" : "System.Double[]",
                "_v" : [ 
                    0.77, 
                    0.61, 
                    0.45, 
                    0.33, 
                    0.25, 
                    0.24, 
                    0.29, 
                    0.38, 
                    0.45, 
                    0.53, 
                    0.62, 
                    0.66, 
                    0.97, 
                    0.99, 
                    0.85, 
                    0.77, 
                    0.81, 
                    0.77, 
                    0.75, 
                    0.72, 
                    0.74, 
                    0.81, 
                    0.82, 
                    0.77
                ]
            },
			'status' : NumberInt(1),
			'realChangeAndroid' : NumberInt(0)
		}, 
		{
			'roomid' : NumberInt(7303),
			'roomname' : '中级房',
			'tablecount' : NumberInt(100),
			'floorscore' : NumberLong(2000),
			'ceilscore' : NumberLong(-1),
			'minplayernum' : NumberInt(2),
			'maxplayernum' : NumberInt(4),
			'enterminscore' : NumberLong(50000),
			'entermaxscore' : NumberLong(-1),
			'broadcastscore' : NumberLong(500000),
			'enableandroid' : NumberInt(1),
			'androidcount' : NumberInt(3),
			'androidmaxusercount' : NumberInt(3),
			'totalstock' : NumberLong(500160000),
			'totalstocklowerlimit' : NumberLong(500000000),
			'totalstockhighlimit' : NumberLong(503200000),
			'systemkillallratio' : NumberInt(0),
			'systemreduceratio' : NumberInt(0),
			'changecardratio' : NumberInt(0),
			'maxjettonscore' : NumberLong(25000),
			'jettons' : {
				'_t' : 'System.Int64[]',
				'_v' : [ 
					NumberLong(1), 
					NumberLong(8), 
					NumberLong(15), 
					NumberLong(22),
					NumberLong(30)
				]
			},
			"androidPercentage" : {
                "_t" : "System.Double[]",
                "_v" : [ 
                    0.77, 
                    0.61, 
                    0.45, 
                    0.33, 
                    0.25, 
                    0.24, 
                    0.29, 
                    0.38, 
                    0.45, 
                    0.53, 
                    0.62, 
                    0.66, 
                    0.97, 
                    0.99, 
                    0.85, 
                    0.77, 
                    0.81, 
                    0.77, 
                    0.75, 
                    0.72, 
                    0.74, 
                    0.81, 
                    0.82, 
                    0.77
                ]
            },
			'status' : NumberInt(1),
			'realChangeAndroid' : NumberInt(0)
		}, 
		{
			'roomid' : NumberInt(7304),
			'roomname' : '高级房',
			'tablecount' : NumberInt(100),
			'floorscore' : NumberLong(5000),
			'ceilscore' : NumberLong(-1),
			'minplayernum' : NumberInt(2),
			'maxplayernum' : NumberInt(4),
			'enterminscore' : NumberLong(100000),
			'entermaxscore' : NumberLong(-1),
			'broadcastscore' : NumberLong(600000),
			'enableandroid' : NumberInt(1),
			'androidcount' : NumberInt(3),
			'androidmaxusercount' : NumberInt(3),
			'totalstock' : NumberLong(500160000),
			'totalstocklowerlimit' : NumberLong(500000000),
			'totalstockhighlimit' : NumberLong(506400000),
			'systemkillallratio' : NumberInt(0),
			'systemreduceratio' : NumberInt(0),
			'changecardratio' : NumberInt(0),
			'maxjettonscore' : NumberLong(75000),
			'jettons' : {
				'_t' : 'System.Int64[]',
				'_v' : [ 
					NumberLong(1), 
					NumberLong(8), 
					NumberLong(15), 
					NumberLong(22),
					NumberLong(30)
				]
			},
			"androidPercentage" : {
                "_t" : "System.Double[]",
                "_v" : [ 
                    0.77, 
                    0.61, 
                    0.45, 
                    0.33, 
                    0.25, 
                    0.24, 
                    0.29, 
                    0.38, 
                    0.45, 
                    0.53, 
                    0.62, 
                    0.66, 
                    0.97, 
                    0.99, 
                    0.85, 
                    0.77, 
                    0.81, 
                    0.77, 
                    0.75, 
                    0.72, 
                    0.74, 
                    0.81, 
                    0.82, 
                    0.77
                ]
            },
			'status' : NumberInt(1),
			'realChangeAndroid' : NumberInt(0)
		}
	],
	"matchmask" : NumberInt(128)
}
	
s.startTransaction()
print("==========================================> "+Date("<YYYY-mm-ddTHH:MM:ssZ>"))
try {
	//delete game_kind 730
    db[game_kind].deleteOne({ 'gameid':730 })
	//delete android_strategy 7301~7304
	db[android_strategy].deleteOne({ 'roomid':7301 })
	db[android_strategy].deleteOne({ 'roomid':7302 })
	db[android_strategy].deleteOne({ 'roomid':7303 })
	db[android_strategy].deleteOne({ 'roomid':7304 })
	//insert game_kind 730
	db[game_kind].insertOne(game_kind_data_730);
	//insert android_strategy 7301~7304
    db[android_strategy].insertOne(android_strategy_data_7301);
    db[android_strategy].insertOne(android_strategy_data_7302);
    db[android_strategy].insertOne(android_strategy_data_7303);
    db[android_strategy].insertOne(android_strategy_data_7304);
	s.commitTransaction();
}catch(e){
	print(e);
	s.abortTransaction();
}
print("==========================================> "+Date("<YYYY-mm-ddTHH:MM:ssZ>"))
print("Successed...");