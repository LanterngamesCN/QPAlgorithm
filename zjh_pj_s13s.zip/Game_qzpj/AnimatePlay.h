#ifndef ANIMATEPLAY_INCLUDE_H
#define ANIMATEPLAY_INCLUDE_H

#include <chrono>

//////////////////////////////////////////////////////////////////////////
//动画类型
//////////////////////////////////////////////////////////////////////////
enum AnimateE {
	kAniNULL,
	kStartGameQ,		//开始游戏动画
	kStartCallBankerQ,	//开始抢庄动画
	kCallBankerQ,		//抢庄倒计时动画
	kMakeBankerQ,		//定庄动画

	kAddScoreQ,			//下注倒计时动画

	kShakeQ,			//摇骰子动画
	kSendCardQ,			//发牌动画
	kOpenCardCountDownQ,//开牌倒计时动画

	kOpenCardQ,			//开牌动画
	kWinLostQ,			//输赢动画
};

//////////////////////////////////////////////////////////////////////////
//动画播放时间
//////////////////////////////////////////////////////////////////////////
#define StartGame						1 //开始游戏(1s)
#define StartCallBanker					1 //开始抢庄(1s)
#define CallBankerCountDown				5 //抢庄倒计时(5s)
#define MakeBanker						1 //定庄动画(1s)
#define AddScoreCountDown				5 //下注倒计时(5s)
#define Shake							2 //摇骰子(2s)
#define SendCard						2 //发牌(2s)
#define OpenCardCountDown				3 //开牌倒计时(3s)
#define OpenCard						4 //开牌动画(4s)
#define WinLost							1 //输赢动画(1s)

//////////////////////////////////////////////////////////////////////////
//定时器延迟时间
//////////////////////////////////////////////////////////////////////////
//叫庄倒计时      开始游戏(1s) + 开始抢庄(1s) + 抢庄倒计时(5s)
#define DELAY_Callbanker				(StartGame+StartCallBanker+CallBankerCountDown)
//下注倒计时      定庄动画(1s) + 下注倒计时(5s)
#define DELAY_AddScore					(MakeBanker+AddScoreCountDown)
//开牌倒计时      摇骰子(2s) + 发牌(2s) + 开牌倒计时(3s)
#define DELAY_OpenCard					(Shake+SendCard+OpenCardCountDown)
//回合结束倒计时   开牌动画(4s)
#define DELAY_RoundEnd					OpenCard
//游戏结束倒计时   开牌动画(4s) + 输赢动画(1s)
#define DELAY_GameEnd					(OpenCard+WinLost)

//////////////////////////////////////////////////////////////////////////
//动画播放 AnimatePlay
// 1.当前动画播放类型 AnimateE
// 2.当前播放剩余时间 leftTime
//////////////////////////////////////////////////////////////////////////
struct AnimatePlay {

	enum StateE {
		CallE,		//抢庄
		ScoreE,		//下注
		OpenE,		//开牌
		RoundEndE,	//回合结束
		GameEndE,	//结束
		MaxE,
	};
	//添加开始时间
	void add_START_time(StateE state, chrono::system_clock::time_point startTime) {
		startTimes[int(state)] = startTime;
	}
	//计算动画剩余播放时长
	//chrono::system_clock::now()
	void calcAnimateDelay(int status, chrono::system_clock::time_point now) {
		aniTy = kAniNULL;
		leftTime = 0;
		time_t startTime = Get_START_time(status);
		//当前时间 - 开始时间
		uint32_t elapsedTime =
			chrono::system_clock::to_time_t(now) - startTime;
		int deltaTime = Get_DELAY_time(status);
		switch (status) {
		case GAME_STATUS_CALL:
			if (elapsedTime < StartGame) {
				//开始游戏动画
				aniTy = kStartGameQ;
				leftTime = StartGame - elapsedTime;
			}
			else if (elapsedTime < (StartGame + StartCallBanker)) {
				//开始抢庄动画
				aniTy = kStartCallBankerQ;
				leftTime = (StartGame + StartCallBanker) - elapsedTime;
			}
			else if (elapsedTime < DELAY_Callbanker) {
				//抢庄倒计时动画
				aniTy = kCallBankerQ;
				leftTime = (StartGame + StartCallBanker + CallBankerCountDown) - elapsedTime;
			}
			break;
		case GAME_STATUS_SCORE:
			if (elapsedTime < MakeBanker) {
				//定庄动画
				aniTy = kMakeBankerQ;
				leftTime = MakeBanker - elapsedTime;
			}
			else if (elapsedTime < DELAY_AddScore) {
				//下注倒计时动画
				aniTy = kAddScoreQ;
				leftTime = DELAY_AddScore - elapsedTime;
			}
			break;
		case GAME_STATUS_OPEN:
			if (elapsedTime < Shake) {
				//摇骰子动画
				aniTy = kShakeQ;
				leftTime = Shake - elapsedTime;
			}
			else if (elapsedTime < (Shake + SendCard)) {
				//发牌动画
				aniTy = kSendCardQ;
				leftTime = (Shake + SendCard) - elapsedTime;
			}
			else if (elapsedTime < DELAY_OpenCard) {
				//开牌倒计时动画
				aniTy = kOpenCardCountDownQ;
				leftTime = DELAY_OpenCard - elapsedTime;
			}
			break;
		case GAME_STATUS_ROUNDEND:
			//开牌动画
			aniTy = kOpenCardQ;
			leftTime = deltaTime - elapsedTime;
			break;
		case GAME_STATUS_END:
			if (elapsedTime < OpenCard) {
				//开牌动画
				aniTy = kOpenCardQ;
				leftTime = OpenCard - elapsedTime;
			}
			else if (elapsedTime < DELAY_GameEnd) {
				//输赢动画
				aniTy = kWinLostQ;
				leftTime = DELAY_GameEnd - elapsedTime;
			}
			break;
		}
	}
private:
	time_t Get_START_time(int status) {
		switch (status) {
		case GAME_STATUS_CALL: return chrono::system_clock::to_time_t(startTimes[CallE]);
		case GAME_STATUS_SCORE: return chrono::system_clock::to_time_t(startTimes[ScoreE]);
		case GAME_STATUS_OPEN: return chrono::system_clock::to_time_t(startTimes[OpenE]);
		case GAME_STATUS_ROUNDEND: return chrono::system_clock::to_time_t(startTimes[RoundEndE]);
		case GAME_STATUS_END: return chrono::system_clock::to_time_t(startTimes[GameEndE]);
		}
		return 0;
	}
	static int Get_DELAY_time(int status) {
		switch (status) {
		case GAME_STATUS_CALL: return DELAY_Callbanker;
		case GAME_STATUS_SCORE: return DELAY_AddScore;
		case GAME_STATUS_OPEN: return DELAY_OpenCard;
		case GAME_STATUS_ROUNDEND: return DELAY_RoundEnd;
		case GAME_STATUS_END: return DELAY_GameEnd;
		}
		return 0;
	}
private:
	chrono::system_clock::time_point startTimes[MaxE];
public:
	//动画类型
	AnimateE aniTy;
	//剩余时间
	int leftTime;
};

#endif