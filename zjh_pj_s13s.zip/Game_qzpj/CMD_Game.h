﻿#ifndef CMD_GAME_H
#define CMD_GAME_H

#include <math.h>
#include <stdio.h>
#include <string.h>
#include "gameDefine.h"

//数值定义
#define MAX_JETTON_MUL							5								//下注倍数个数
#define MAX_BANKER_MUL							4								//叫庄倍数个数
#define MAX_BANKER_CALL							4+1								//叫庄最大倍数

#endif
