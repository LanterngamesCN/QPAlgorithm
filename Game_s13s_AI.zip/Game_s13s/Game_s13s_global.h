#ifndef GAME_S13S_GLOBAL_H
#define GAME_S13S_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(GAME_S13S_LIBRARY)
#  define GAME_S13S_EXPORT Q_DECL_EXPORT
#else
#  define GAME_S13S_EXPORT Q_DECL_IMPORT
#endif

#endif // GAME_S13S_GLOBAL_H
