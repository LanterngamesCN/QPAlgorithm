#pragma once

#include <map>
#include <muduo/net/EventLoopThread.h>
#include <muduo/net/EventLoop.h>
#include <muduo/net/TimerId.h>

#include "ITableFrameSink.h"
#include "ITableFrame.h"
#include "ISaveReplayRecord.h"

#include "s13s.h"

#define GAME_STATUS_INIT                        GameStatus::GAME_STATUS_INIT //初始状态
#define GAME_STATUS_READY						GameStatus::GAME_STATUS_FREE //空闲状态
#define GAME_STATUS_START						GameStatus::GAME_STATUS_START//进行状态
#define GAME_STATUS_GROUP						(GAME_STATUS_START+1) //理牌状态
#define GAME_STATUS_OPEN						(GAME_STATUS_START+2) //开牌状态
#define GAME_STATUS_PREEND						(GAME_STATUS_START+3) //结束前状态
#define GAME_STATUS_END				    	    GameStatus::GAME_STATUS_END  //游戏结束
#define GAME_STATUS_NEXT			            (GAME_STATUS_END+1) //下一局

#include "AnimatePlay.h"

#define FloorScore		(m_pTableFrame->GetGameRoomInfo()->floorScore)//底注
#define CeilScore		(m_pTableFrame->GetGameRoomInfo()->ceilScore)//顶注
#define CellScore		(FloorScore)//底注
#define JettionList     (m_pTableFrame->GetGameRoomInfo()->jettons)//筹码表

#define ThisTableId		(m_pTableFrame->GetTableId())
#define ThisGameId		(m_pTableFrame->GetGameRoomInfo()->gameId)
#define ThisRoomId		(m_pTableFrame->GetGameRoomInfo()->roomId)
#define ThisRoomName	(m_pTableFrame->GetGameRoomInfo()->roomName)
#define ThisThreadTimer	(m_pTableFrame->GetLoopThread()->getLoop())

#define EnterMinScore (m_pTableFrame->GetGameRoomInfo()->enterMinScore)//进入最小分
#define EnterMaxScore (m_pTableFrame->GetGameRoomInfo()->enterMaxScore)//进入最大分

#define ByChairId(chairId)	(m_pTableFrame->GetTableUserItem(chairId))
#define ByUserId(userId)	(m_pTableFrame->GetUserItemByUserId(userId))

#define UserIdBy(chairId) ByChairId(chairId)->GetUserId()
#define ChairIdBy(userId) ByUserId(userId)->GetChairId()

#define ScoreByChairId(chairId) ByChairId(chairId)->GetUserScore()
#define ScoreByUserId(userId) ByUserId(userId)->GetUserScore()

#define StockScore m_pTableFrame->GetGameRoomInfo()->totalStock//(storageInfo_.i64CurStock) //系统当前库存
#define StockLowLimit m_pTableFrame->GetGameRoomInfo()->totalStockLowerLimit//(storageInfo_.i64LowestStock)//系统输分不得低于库存下限，否则赢分
#define StockHighLimit m_pTableFrame->GetGameRoomInfo()->totalStockHighLimit//(storageInfo_.i64HighestStock)//系统赢分不得大于库存上限，否则输分

#define StockSecondLowLimit m_pTableFrame->GetGameRoomInfo()->totalStockSecondLowerLimit
#define StockSecondHighLimit m_pTableFrame->GetGameRoomInfo()->totalStockSecondHighLimit

//配置文件
#define INI_FILENAME "./conf/s13s_config.ini"
//#define INI_CARDLIST "./conf/s13s_cardList.ini"

static std::string StringStat(uint8_t status) {
	switch (status) {
	case GAME_STATUS_INIT: return "eInit";
	case GAME_STATUS_READY: return "eReady";
	case GAME_STATUS_START: return "ePlaying";
	case GAME_STATUS_GROUP: return "eGroup";
	case GAME_STATUS_OPEN: return "eOpen";
	case GAME_STATUS_PREEND:
	case GAME_STATUS_END: return "eEnd";
	}
	return "nil";
}

static std::string StringPlayerStat(uint8_t status) {
	switch (status) {
	case sGetout: return "sGetout";
	case sFree: return "sFree";
	case sStop: return "sStop";
	case sSit: return "sSit";
	case sReady: return "sReady";
	case sPlaying: return "sPlaying";
	case sOffline: return "sOffline";
	case sLookon: return "sLookon";
	case sGetoutAtplaying: return "sGetoutAtplaying";
	}
	return "nil";
}

//游戏流程
class CTableFrameSink : public ITableFrameSink
{
public:
    CTableFrameSink(void);
    ~CTableFrameSink(void);
public:
    //游戏开始
    virtual void OnGameStart();
    //游戏结束
    virtual bool OnEventGameConclude(uint32_t dwChairID, uint8_t GETag);
    //发送场景
    virtual bool OnEventGameScene(uint32_t dwChairID, bool bIsLookUser);
    //游戏消息
    virtual bool OnGameMessage(uint32_t chairid, uint8_t subid, const uint8_t* data, uint32_t datasize);
    //用户进入
    virtual bool OnUserEnter(int64_t dwUserID, bool bIsLookUser);
    //用户准备
    virtual bool OnUserReady(int64_t dwUserID, bool bIsLookUser);
    //用户离开
    virtual bool OnUserLeft(int64_t dwUserID, bool bIsLookUser);
    //能否加入
    virtual bool CanJoinTable(int64_t userId);
    //能否离开
    virtual bool CanLeftTable(int64_t userId);
    //设置指针
    virtual bool SetTableFrame(shared_ptr<ITableFrame>& pTableFrame);

    virtual void RepositionSink() ;
private:
	//计算机器人税收
	//int64_t CalculateAndroidRevenue(int64_t score);
    //清理游戏数据
    virtual void ClearGameData();
    //初始化游戏数据
    void InitGameData();
    //清除所有定时器
    inline void ClearAllTimer();
	//理牌
	void OnTimerGroupCard();
	//定牌
	void OnUserSelect(uint32_t chairId, int groupIndex);
	//摊牌
	void OnTimerOpenCard();
	//结束/下一局
    void OnTimerGameEnd();
	//踢人用户清理
	void clearKickUsers();
    //读取库存配置
    void ReadConfigInformation();
	//换牌策略分析
	//收分时概率性玩家拿小牌，AI拿大牌
	//放水时概率性AI拿小牌，玩家拿大牌
	void AnalysePlayerCards();
	//让系统赢或输
	void LetSysWin(bool sysWin);
	//玩家之间两两比牌
	void StartCompareCards();
private:
	//累计匹配时长
	double totalMatchSeconds_;
	//分片匹配时长(可配置)，比如0.1s做一次检查
	double sliceMatchSeconds_;
	//匹配真人超时时长(可配置)
	double timeoutMatchSeconds_;
	//补充机器人超时时长(可配置)
	double timeoutAddAndroidSeconds_;
	//准备定时器
	void OnTimerGameReadyOver();
	//结束准备，开始游戏
	void GameTimerReadyOver();
	//游戏开局前检查
	void CheckGameStart();
	//设置托管，理牌/摊牌/结算
	bool IsTrustee(void);
protected:
	//打印真人游戏局log
	bool writeRealLog_;
	time_t lastReadCfgTime_;
	int readIntervalTime_;//更新配置间隔时间
	//空闲踢人间隔时间
	int kickPlayerIdleTime_;
	STD::Random rand_;
	int maxAndroid_;
protected:
	uint8_t gameStatus_;
	//牌局编号
	std::string strRoundID_;
	//游戏逻辑
	S13S::CGameLogic g;
	//各个玩家手牌
	uint8_t handCards_[GAME_PLAYER][MAX_COUNT];
	//玩家牌型分析结果
	S13S::CGameLogic::handinfo_t handInfos_[GAME_PLAYER];
	//直接使用
	S13S::CGameLogic::handinfo_t* phandInfos_[GAME_PLAYER];
	//各个玩家比牌结果
	s13s::CMD_S_CompareCards compareCards_[GAME_PLAYER];
	//各个玩家输赢积分
	s13s::GameEndScore score_[GAME_PLAYER];
	//彼此相对输赢/[i]输赢[j]得水
	int eachWinLostScore_[GAME_PLAYER][GAME_PLAYER];
	//本局开始时间/本局结束时间
	chrono::system_clock::time_point roundStartTime_;
	chrono::system_clock::time_point roundEndTime_;
	uint32_t groupTime_;//理牌时间
	uint32_t openCardTime_;//开牌比牌时间
	uint32_t shootTime_;//打枪/全垒打时间
	uint32_t winLostTime_;//结算飘金币时间
	uint32_t nextTime_;//下一局倒计时间
	//确定牌型的玩家数
	int selectcount;
    //内部使用玩家状态，false:无效/中途加入桌子
    bool bPlaying_[GAME_PLAYER];
	enum {
		Exchange = 0,	//换牌
		NoExchange,		//不换
		MaxExchange,
	};
	//对局日志
	tagGameReplay m_replay;
	AnimatePlay aniPlay_;
	//桌子指针
	std::shared_ptr<ITableFrame> m_pTableFrame;
	//准备定时器
	muduo::net::TimerId timerIdGameReadyOver_;
	//理牌定时器
	muduo::net::TimerId timerGroupID_;
	//摊牌定时器
	muduo::net::TimerId timerOpenCardID_;
	//结束定时器
	muduo::net::TimerId timerGameEndID_;
	muduo::net::TimerId timerIdReadConfig_;

    int64_t m_lMarqueeMinScore; // 跑马灯最小分值
	bool m_bPlayerOperated[GAME_PLAYER]; //本局是否有操作
    bool m_bRoundEndExit[GAME_PLAYER]; //本局结束后退出

	int32_t m_i32LowerChangeRate;
	int32_t m_i32HigherChangeRate;
};
